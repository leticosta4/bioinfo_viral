import pandas as pd
import time


df = pd.read_csv('salaries.csv')
print(df)
print("columns:", df.columns)

print("\n\Coluna de interesse: Salaries")
print(df[str('salary')])

#etapa de ordenação
print("\n\nOrdenando:")
print("ordem ascendente:")

sorting_initial_time =  (time.time()) #registro de tempo
ord1 = df.sort_values(by='salary')
sorting_final_time = (time.time())
print(df['salary'].sort_values())

print(f"tempo de usado para ordenar de forma crescente (a partir do primeiro df): {sorting_final_time - sorting_initial_time} seg")


print("\n\nordem descendente:")
sorting2_initial_time =  (time.time())
ord2 = df.sort_values(by='salary', ascending=False)
sorting2_final_time = (time.time())
print(df['salary'].sort_values(ascending=False))
print(f"tempo de usado para ordenar de forma decrescente (a partir do primeiro df): {sorting2_final_time - sorting2_initial_time} seg")


sorting3_initial_time =  (time.time())
ord1.sort_values(by='salary', ascending=False)
sorting3_final_time = (time.time())
print(df[str('salary')].sort_values(ascending=False))

print(f"tempo de usado para reordenar a partir da coluna decrescente): {sorting3_final_time - sorting3_initial_time} seg")

sorting4_initial_time =  (time.time())
ord2.sort_values(by='salary')
sorting4_final_time = (time.time())
print(df[str('salary')].sort_values())

print(f"tempo de usado para reordenar a partir da coluna decrescente): {sorting4_final_time - sorting4_initial_time} seg")

#teste de estabilidade
print("\n\nDataFrame depois de ter suas colunas ordenadas")
print(df)
# time_dict = {
#     'Tempo ord. crescente do Dataframe inicial': 
#     'Tempo ord. decrescente do Dataframe inicial':
#     'Primeira ordenaçao em forma inversa':
#     'Segunda ordenaçao em forma inversa':
# }