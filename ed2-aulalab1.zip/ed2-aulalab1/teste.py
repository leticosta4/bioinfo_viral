import pandas as pd
import time

df = pd.read_csv('salaries.csv')
print(df)
print("salarios:", df['salary'])
print(df.sort_values(by='salary'))
ord1 = df.sort_values(by='salary')
print(df)